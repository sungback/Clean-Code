package performance;

public class TestSB {
	public static void main(String[] args) {
		System.gc();
		long startTime = System.currentTimeMillis();
		StringBuilder sb = new StringBuilder();
		for (int i = 1; i <= 20000; i++) {
			sb.append("이 문자열을 20000번 계속 붙이자!");
		}
		long endTime = System.currentTimeMillis();
		long afterMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		System.out.println("사용 메모리(MB) : " + afterMemory / (1024.0*1024.0));
		System.out.println("응답 시간 : " + (endTime - startTime) / 1000.0);
	}
}
