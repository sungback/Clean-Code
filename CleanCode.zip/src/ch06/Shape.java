package ch06;

public interface Shape {
	public double area();
}
