package ch06;

public class Test1 {
	public static void main(String[] args) {
		Square square = new Square();
		square.side = 5;
		System.out.println(square.area());
		
		Rectangle rectagle = new Rectangle();
		rectagle.height = 3;
		rectagle.width = 5;
		System.out.println(rectagle.area());
		
		Circle circle = new Circle();
		circle.radius = 7;
		System.out.println(circle.area());
	}
}
