package ch06;

// 정사각형
public class Square implements Shape {

	private Point topLeft;
	public double side;
	
	@Override
	public double area() {
		return side * side;
	}

}
