package ch06;

public class Rectangle implements Shape {

	private Point topLeft;
	public double height;
	public double width;
	
	@Override
	public double area() {
		return height * width;
	}

}
