package algo;

import java.util.HashMap;

public class 완주 {
    public String solution(String[] participant, String[] completion) {
        String answer = "";
        HashMap<String, Integer> map = new HashMap<>(); // 참가자_이름 : 인원_수
        // 참가자 담기
        for (String name : participant) {
			map.put(name, map.getOrDefault(name, 0) + 1);
		}
        // System.out.println(map); // {leo=1, eden=1, kiki=1}, ..., {ana=1, mislav=2, stanko=1}
        // 완주자는 -1을 한다
        for (String name : completion) {
			map.put(name, map.get(name) - 1);
		}
        // System.out.println(map); // {leo=1, eden=0, kiki=0},.., {ana=0, mislav=1, stanko=0}
        // System.out.println(map.keySet()); // [leo, eden, kiki], ..., [ana, mislav, stanko]
        // 정답
        for (String name : map.keySet()) {
			if(map.get(name) != 0) {
				answer = name;
				break;
			}
		}
        return answer;
    }
    public static void main(String[] args) {
    	완주 obj = new 완주();
    	String[] participant = { "leo", "kiki", "eden" };
    	String[] completion = { "eden", "kiki" };
    	System.out.println( obj.solution(participant, completion) ); // leo
    	String[] participant2 = { "marina", "josipa", "nikola", "vinko", "filipa" };
    	String[] completion2 = { "josipa", "filipa", "marina", "nikola" };
    	System.out.println( obj.solution(participant2, completion2) ); // vinko
    	String[] participant3 = { "mislav", "stanko", "mislav", "ana" };
    	String[] completion3 = { "stanko", "ana", "mislav" };
    	System.out.println( obj.solution(participant3, completion3) ); // mislav
	}
}
//["leo", "kiki", "eden"]	["eden", "kiki"]	"leo"
//["marina", "josipa", "nikola", "vinko", "filipa"]	["josipa", "filipa", "marina", "nikola"]	"vinko"
//["mislav", "stanko", "mislav", "ana"]	["stanko", "ana", "mislav"]	"mislav"