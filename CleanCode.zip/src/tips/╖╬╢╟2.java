package tips;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class 로또2 {
	public static void main(String[] args) {
		int count = 0;
		while(count < 5) {
			List<Integer> balls = new ArrayList<>();
			for (int i = 1; i <= 45; i++) {
				balls.add(i);
			}
			Collections.shuffle(balls); //섞는다
			List<Integer> lotto = balls.subList(0, 6); // 6개 뽑기
			Collections.sort(lotto); // 정렬
			int sum = 0;
			for (int i : lotto) {
				sum += i;
			}
			if(sum >= 100 && sum <= 170) {
				System.out.println("lotto=" + lotto + ",sum=" + sum);
				count++;	
			}
		}
	}// main
}
