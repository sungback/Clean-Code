package tips;
public class 마름모 {
	public static void main(String[] args) {
		int number = 5;
		for (int line = 1; line <= number; line++) { // 위 5줄
			for (int j = number; j > line; j--) { // 1:5,4,3,2(4칸), 2:5,4,3(3칸), 3:5,4(2칸), 4:5(1칸), 5:0칸
				System.out.print(" ");
			}
			int k_stars = 2 * line - 1; // 각 줄의 출력할 별의 갯수 : 1줄:1,2줄:3,3줄:5,4줄:7,5줄:9
			for (int k = 1; k <= k_stars; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		for (int line = 1; line < number; line++) { // 아래 4줄
			for (int j = 1; j <= line; j++) {
				System.out.print(" ");
			}
			int n_stars = 2 * number - 1 - line; // 8,7,6,5
			for (int k = line; k < n_stars; k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
