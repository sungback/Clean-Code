package tips;

import java.util.Random;
import java.util.TreeSet;
//[ 로또번호 생성기 ]
//1. 난수 : 1~45 : Random
//2. 중복없이 6개 저장 : TreeSet
//3. 정렬
//4. 5게임 : while
//5. 합이 100~170인 것만 사용
public class 로또 {
	public static void main(String[] args) { // 16줄
		int count = 0;
		Random r = new Random();
		while(count < 5) { // 5게임
			TreeSet<Integer> lotto = new TreeSet<>(); // 중복X, 자동정렬
			while(lotto.size() < 6) { // 로또번호 6개 저장
				lotto.add( r.nextInt(45) + 1 ); // (0~44)+1 ==> 1~45
			}
			int sum = 0;
			for (int i : lotto) { // 덧셈, 합계
				sum += i;
			}
			if(sum >= 100 && sum <= 170) {
				System.out.println("lotto=" + lotto + ", sum=" + sum);
				count++;				
			}
		}
	}// main
}
