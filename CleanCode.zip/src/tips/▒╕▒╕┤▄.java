package tips;

// 2*1=2	3*1=3	4*1=4	5*1=5	6*1=6	7*1=7	8*1=8	9*1=9
public class 구구단 {
	public static void main(String[] args) {
		for(int i = 1; i <= 9; i++) { // 곱할 숫자
			for(int dan = 2; dan <= 9; dan++) { // 단
				System.out.print(dan + "*" + i + "=" + (dan*i) + "\t");
			}
			System.out.println();
		}
	}
}
