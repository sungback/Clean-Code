package ch03;

public class Ch0301 {
	public static String renderPageWithSetupsAndTeardowns( PageData pageData, boolean isSuite) throws Exception {
		isTestPage(pageData, isSuite);
		return pageData.getHtml(); 
	}
	private static void isTestPage(PageData pageData, boolean isSuite) {
		boolean isTestPage = pageData.hasAttribute("Test"); 
		if (isTestPage) {
			WikiPage testPage = pageData.getWikiPage(); 
			StringBuffer newPageContent = new StringBuffer(); 
			includeSetupPages(testPage, newPageContent, isSuite); 
			newPageContent.append(pageData.getContent()); 
			includeTeardownPages(testPage, newPageContent, isSuite); 
			pageData.setContent(newPageContent.toString());
		}
	}
	public static String renderPageWithSetupsAndTeardowns( PageData pageData, boolean isSuite) throws Exception { 
		   if (isTestPage(pageData)) 
		   	includeSetupAndTeardownPages(pageData, isSuite); 
		   return pageData.getHtml();
		}
}
